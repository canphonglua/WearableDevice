


#include "minitransfer.h"



wire::wire(void){

}

wire::~wire(void){

}

void wire::begin(void){

}

void wire::beginTransmission(uint8_t i2caddr){

}

void wire::endTransmission(bool b){

}

void wire::read(){

}

void wire::write(uint8_t c){

}


